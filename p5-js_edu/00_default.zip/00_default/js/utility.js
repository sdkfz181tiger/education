console.log("Hello utility.js!!");

//==========
// Utility(main)
