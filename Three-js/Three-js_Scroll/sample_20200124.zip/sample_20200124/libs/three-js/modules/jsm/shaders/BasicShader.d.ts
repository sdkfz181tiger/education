import {
	Uniform
} from '../../../src/Three';

export const BasicShader: {
	uniforms: {};
	vertexShader: string;
	fragmentShader: string;
};
