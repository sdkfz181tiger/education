import { NodeMaterial } from './NodeMaterial';

export class StandardNodeMaterial extends NodeMaterial {

	constructor();

}
