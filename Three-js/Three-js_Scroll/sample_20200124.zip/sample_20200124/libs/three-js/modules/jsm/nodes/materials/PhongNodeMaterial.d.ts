import { NodeMaterial } from './NodeMaterial';

export class PhongNodeMaterial extends NodeMaterial {

	constructor();

}
