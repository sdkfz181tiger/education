import { Node } from './Node';

export namespace NodeUtils {

	export const elements: string[];

	export function addShortcuts( proto: Node, proxy: string, list: any[] ): void;

}
