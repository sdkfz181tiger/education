import { NodeMaterial } from './NodeMaterial';

export class MeshStandardNodeMaterial extends NodeMaterial {

	constructor();

}
