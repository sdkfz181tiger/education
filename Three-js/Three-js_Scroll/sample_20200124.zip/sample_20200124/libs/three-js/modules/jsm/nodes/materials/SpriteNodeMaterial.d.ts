import { NodeMaterial } from './NodeMaterial';

export class SpriteNodeMaterial extends NodeMaterial {

	constructor();

}
