"use strict";

function setup(){
	createCanvas(windowWidth, windowHeight);
}

function draw(){
	background(66, 66, 33);
}